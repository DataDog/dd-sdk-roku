' Unless explicitly stated otherwise all files in this repository are licensed under the Apache License Version 2.0.
' This product includes software developed at Datadog (https://www.datadoghq.com/).
' Copyright 2022-Today Datadog, Inc.
'*****************************************************************
'* Utility functions around time
'*****************************************************************

' ----------------------------------------------------------------
' Returns the current timestamp in milliseconds since EPOCH
' @return (longinteger) the number of millis since jan 1st 1970
' ----------------------------------------------------------------
function datadogroku_getTimestamp() as longinteger
    date = CreateObject("roDateTime")
    seconds& = date.AsSeconds() ' number of seconds since EPOCH
    millis& = date.GetMilliseconds() ' number of millisecond in current second [0-999]
    timestamp& = (seconds& * 1000) + millis&
    return timestamp&
end function

' ----------------------------------------------------------------
' Converts a duration in nanoseconds (longinteger) into a duration in milliseconds (longinteger)
' @param nanoseconds (longinteger) a duration in nanoseconds
' @return (longinteger) the duration in milliseconds
' ----------------------------------------------------------------
function datadogroku_nanosToMillis(nanoseconds as longinteger) as longinteger
    ratio& = 1000000
    result& = nanoseconds / ratio&
    return result&
end function

' ----------------------------------------------------------------
' Converts a duration in milliseconds (longinteger) into a duration in seconds (double)
' @param milliseconds (longinteger) a duration in milliseconds
' @return (double) the duration in seconds
' ----------------------------------------------------------------
function datadogroku_millisToSec(milliseconds as longinteger) as double
    ratio# = 1000
    result# = milliseconds / ratio#
    return result#
end function

' ----------------------------------------------------------------
' Converts a duration in milliseconds (longinteger) into a duration in nanoseconds (longinteger)
' @param milliseconds (longinteger) a duration in milliseconds
' @return (longinteger) the duration in nanoseconds
' ----------------------------------------------------------------
function datadogroku_millisToNanos(milliseconds as longinteger) as longinteger
    ratio& = 1000000
    result& = milliseconds * ratio&
    return result&
end function

' ----------------------------------------------------------------
' Converts a duration in seconds (double) into a duration in milliseconds (longinteger)
' @param seconds (double) a duration in seconds
' @return (longinteger) the duration in milliseconds
' ----------------------------------------------------------------
function datadogroku_secToMillis(seconds as double) as longinteger
    ratio& = 1000
    result& = seconds * ratio&
    return result&
end function

' ----------------------------------------------------------------
' Converts a duration in seconds (double) into a duration in nanoseconds (longinteger)
' @param seconds (double) a duration in seconds
' @return (longinteger) the duration in nanoseconds
' ----------------------------------------------------------------
function datadogroku_secToNanos(seconds as double) as longinteger
    ratio& = 1000000000
    result& = seconds * ratio&
    return result&
end function

' ----------------------------------------------------------------
' Checks whether a dynamic value can safely be used as a timestamp
' (i.e. assigned to a longinteger variable)
' @param value (dynamic) the value to check
' @return (boolean) true if the value is a numeric type
' ----------------------------------------------------------------
function datadogroku_isTimestamp(value as dynamic) as boolean
    if (value = invalid)
        return false
    end if
    return GetInterface(value, "ifInt") <> invalid or GetInterface(value, "ifLongInt") <> invalid or GetInterface(value, "ifDouble") <> invalid
end function