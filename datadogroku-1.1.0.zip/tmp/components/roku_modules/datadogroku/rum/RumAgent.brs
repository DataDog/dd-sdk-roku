' Unless explicitly stated otherwise all files in this repository are licensed under the Apache License Version 2.0.
' This product includes software developed at Datadog (https://www.datadoghq.com/).
' Copyright 2022-Today Datadog, Inc.
'import "pkg:/source/roku_modules/datadogroku/rum/rumRawEvents.bs"
'import "pkg:/source/roku_modules/datadogroku/rum/rumHelper.bs"
'import "pkg:/source/roku_modules/datadogroku/datadogSdk.bs"
'import "pkg:/source/roku_modules/datadogroku/internalLogger.bs"
' *****************************************************************
' * RumAgent: a background component listening for internal events
' *     to write relevant RUM Event to Datadog.
' *****************************************************************

' ----------------------------------------------------------------
' Initialize the component
' ----------------------------------------------------------------
sub init()
    datadogroku_ddLogThread("RumAgent.init()")
    m.port = createObject("roMessagePort")
    m.top.functionName = "datadogroku_rumAgentLoop"
    m.top.control = "RUN"
end sub

' ----------------------------------------------------------------
' Main RumAgent loop
' ----------------------------------------------------------------
sub datadogroku_rumAgentLoop()
    datadogroku_ddLogThread("RumAgent.rumAgentLoop()")
    datadogroku_ensureSetup()
    sendCrash(m.top.lastExitOrTerminationReason)
    addConfigTelemetry(m.top.configuration)
    while (true)
        msg = wait(m.top.keepAliveDelayMs, m.port)
        m.top.rumScope.callfunc("handleEvent", datadogroku_keepAliveEvent(), m.top.writer)
        msgType = type(msg)
        if (msgType <> "Invalid")
            datadogroku_ddLogWarning("Unexpected message " + msgType + ": " + FormatJson(msg))
        end if
    end while
end sub

' ----------------------------------------------------------------
' Starts a view
' @param name (string) the view name (human-readable)
' @param url (string) the view url (developer identifier)
' @param context (object) an assocarray of custom attributes to add to the view
' ----------------------------------------------------------------
sub startView(name as string, url as string, context = {} as object)
    datadogroku_ddLogThread("RumAgent.startView()")
    datadogroku_ensureSetup()
    m.top.rumScope.callfunc("handleEvent", datadogroku_startViewEvent(name, url, context), m.top.writer)
    m.top.rumScope.callfunc("handleEvent", datadogroku_keepAliveEvent(), m.top.writer)
end sub

' ----------------------------------------------------------------
' Stops a view
' @param name (string) the view name (human-readable)
' @param url (string) the view url (developer identifier)
' @param context (object) an assocarray of custom attributes to add to the view
' ----------------------------------------------------------------
sub stopView(name as string, url as string, context = {} as object)
    datadogroku_ddLogThread("RumAgent.stopView()")
    datadogroku_ensureSetup()
    m.top.rumScope.callfunc("handleEvent", datadogroku_stopViewEvent(name, url, context), m.top.writer)
end sub

' ----------------------------------------------------------------
' Adds an action
' @param action (object) the action to track
' @param context (object) an assocarray of custom attributes to add to the view
' ----------------------------------------------------------------
sub addAction(action as object, context = {} as object)
    datadogroku_ddLogThread("RumAgent.addAction()")
    datadogroku_ensureSetup()
    m.top.rumScope.callfunc("handleEvent", datadogroku_addActionEvent(action, context), m.top.writer)
end sub

' ----------------------------------------------------------------
' Adds an error
' @param exception (object) the caught exception object
' @param context (object) an assocarray of custom attributes to add to the view
' ----------------------------------------------------------------
sub addError(exception as object, context = {} as object)
    datadogroku_ddLogThread("RumAgent.addError()")
    datadogroku_ensureSetup()
    m.top.rumScope.callfunc("handleEvent", datadogroku_addErrorEvent(exception, context), m.top.writer)
end sub

' ----------------------------------------------------------------
' Adds a resource
' @param resource (object) the tracked resource object (as retrieved from the roSystemLog)
' @param context (object) an assocarray of custom attributes to add to the view
' ----------------------------------------------------------------
sub addResource(resource as object, context = {} as object)
    datadogroku_ddLogThread("RumAgent.addResource()")
    datadogroku_ensureSetup()
    m.top.rumScope.callfunc("handleEvent", datadogroku_addResourceEvent(resource, context), m.top.writer)
end sub

' ----------------------------------------------------------------
' Sends a crash report from a previous view
' @param lastExitOrTerminationReason (object) the lastExitOrTerminationReason parameter
' from the channel's RunUserInterface
' ----------------------------------------------------------------
sub sendCrash(lastExitOrTerminationReason as string)
    datadogroku_ensureSetup()
    crashReporter = CreateObject("roSGNode", "datadogroku_RumCrashReporterTask")
    crashReporter.writer = m.top.writer
    if (m.top.osVersionMajor.toInt() >= 13)
        appManager = createObject("roAppManager")
        lastExitInfo = appManager.GetLastExitInfo()
        exitCode = lastExitInfo.exit_code
        crashReporter.lastExitOrTerminationReason = lastExitInfo.exit_code
        crashReporter.lastExitConsoleLog = lastExitInfo.console_log
    else
        crashReporter.lastExitOrTerminationReason = lastExitOrTerminationReason
        crashReporter.lastExitConsoleLog = ""
    end if
    crashReporter.instanceId = m.instanceId
    crashReporter.control = "RUN"
end sub

' ----------------------------------------------------------------
' Adds a telemetry config event
' @param configuration (object) the configuration information
' ----------------------------------------------------------------
sub addConfigTelemetry(configuration as object)
    datadogroku_ddLogThread("RumAgent.addConfigTelemetry()")
    datadogroku_ensureSetup()
    m.top.telemetryScope.callfunc("handleEvent", datadogroku_addTelemetryConfigEvent(configuration), m.top.writer)
end sub

' ----------------------------------------------------------------
' Adds a telemetry error event
' @param exception (object) the caught exception object
' ----------------------------------------------------------------
sub addErrorTelemetry(exception as object)
    datadogroku_ddLogThread("RumAgent.addErrorTelemetry()")
    datadogroku_ensureSetup()
    m.top.telemetryScope.callfunc("handleEvent", datadogroku_addTelemetryErrorEvent(exception), m.top.writer)
end sub

' ----------------------------------------------------------------
' Adds a telemetry debug event
' @param message (string) the message to send
' ----------------------------------------------------------------
sub addDebugTelemetry(message as string)
    datadogroku_ddLogThread("RumAgent.addDebugTelemetry()")
    datadogroku_ensureSetup()
    m.top.telemetryScope.callfunc("handleEvent", datadogroku_addTelemetryDebugEvent(message), m.top.writer)
end sub

' ----------------------------------------------------------------
' Ensure all dependencies are present (from DI or generated)
' ----------------------------------------------------------------
sub datadogroku_ensureSetup()
    datadogroku_ensureRumScope()
    datadogroku_ensureTelemetryScope()
    datadogroku_ensureUploader()
    datadogroku_ensureWriter()
end sub

' ----------------------------------------------------------------
' Sets the root RUM scope node from the top node's field,
' or instantiate one.
' ----------------------------------------------------------------
sub datadogroku_ensureRumScope()
    if (m.top.rumScope = invalid)
        m.instanceId = CreateObject("roDeviceInfo").GetRandomUUID()
        datadogroku_ddLogWarning("RumViewScope.instanceId:" + m.instanceId)
        m.global.addFields({
            datadogRumContext: {}
        })
        datadogRumContext = m.global.datadogRumContext
        datadogRumContext.applicationId = m.top.applicationId
        datadogRumContext.instanceId = m.instanceId
        m.global.setField("datadogRumContext", datadogRumContext)
        datadogroku_ddLogVerbose("Creating RumApplicationScope")
        m.top.rumScope = CreateObject("roSGNode", "datadogroku_RumApplicationScope")
        m.top.rumScope.applicationId = m.top.applicationId
        m.top.rumScope.service = m.top.service
        m.top.rumScope.version = m.top.version
        m.top.rumScope.deviceName = m.top.deviceName
        m.top.rumScope.deviceModel = m.top.deviceModel
        m.top.rumScope.osVersion = m.top.osVersion
        m.top.rumScope.osVersionMajor = m.top.osVersionMajor
        m.top.rumScope.sessionSampleRate = m.top.sessionSampleRate
    end if
end sub

' ----------------------------------------------------------------
' Sets the telemetry scope node from the top node's field,
' or instantiate one.
' ----------------------------------------------------------------
sub datadogroku_ensureTelemetryScope()
    if (m.top.telemetryScope = invalid)
        datadogroku_ddLogVerbose("Creating RumTelemetryScope")
        m.top.telemetryScope = CreateObject("roSGNode", "datadogroku_RumTelemetryScope")
    end if
end sub

' ----------------------------------------------------------------
' Sets the uploader node from the top node's field,
' or instantiate one.
' ----------------------------------------------------------------
sub datadogroku_ensureUploader()
    uploader = m.top.uploader
    if (m.top.uploader = invalid)
        datadogroku_ddLogVerbose("Creating MultiTrackUploaderTask")
        uploader = CreateObject("roSGNode", "datadogroku_MultiTrackUploaderTask")
    end if
    trackId = "rum_" + m.top.threadInfo().node.address
    tracks = (function(uploader)
            __bsConsequent = uploader.tracks
            if __bsConsequent <> invalid then
                return __bsConsequent
            else
                return {}
            end if
        end function)(uploader)
    tracks[trackId] = {
        url: datadogroku_getIntakeUrl(m.top.site, "rum")
        trackType: "rum"
        payloadPrefix: ""
        payloadPostfix: ""
        contentType: "text/plain;charset=UTF-8"
        queryParams: {
            ddsource: datadogroku_agentSource()
            ddtags: "sdk_version:" + datadogroku_sdkVersion() + ",env:" + m.top.env
        }
    }
    uploader.tracks = tracks
    uploader.clientToken = m.top.clientToken
    m.top.uploader = uploader
end sub

' ----------------------------------------------------------------
' Sets the writer node from the top node's field,
' or instantiate one.
' ----------------------------------------------------------------
sub datadogroku_ensureWriter()
    writer = m.top.writer
    if (writer = invalid)
        datadogroku_ddLogVerbose("Creating WriterTask")
        writer = CreateObject("roSGNode", "datadogroku_WriterTask")
    end if
    writer.trackType = "rum"
    writer.payloadSeparator = chr(10)
    m.top.writer = writer
end sub