' Unless explicitly stated otherwise all files in this repository are licensed under the Apache License Version 2.0.
' This product includes software developed at Datadog (https://www.datadoghq.com/).
' Copyright 2022-Today Datadog, Inc.
' ****************************************************************
' * RumApplicationScope: handles the Application level,
' * delegates most to the children
' ****************************************************************

' ----------------------------------------------------------------
' Initialize the component
' ----------------------------------------------------------------
sub init()
end sub

' ----------------------------------------------------------------
' Returns the current context from this scope
' @param _ph (dynamic) no-op argument to avoid random crash on older Roku devices
' @returns (object) the current context
' ----------------------------------------------------------------
function getRumContext(_ph as dynamic) as object
    datadogroku_setupIfNeeded()
    return {
        applicationId: m.applicationId
        service: m.service
        applicationVersion: m.version
        deviceName: m.deviceName
        deviceModel: m.deviceModel
        osVersion: m.osVersion
        osVersionMajor: m.osVersionMajor
    }
end function

' ----------------------------------------------------------------
' Handles an internal event
' @param event (object) the event to handle
' @param writer (object) the writer node (see WriterTask component)
' ----------------------------------------------------------------
sub handleEvent(event as object, writer as object)
    datadogroku_setupIfNeeded()
    m.sessionScope.callfunc("handleEvent", event, writer)
end sub

' ----------------------------------------------------------------
' Returns information about whether the current scope can handle more events or not
' @param _ph (dynamic) no-op argument to avoid random crash on older Roku devices
' @return (boolean) `true` if this scope expects more event, `false` if it's complete
' ----------------------------------------------------------------
function isActive(_ph as dynamic) as boolean
    ' TODO
    return invalid
end function

sub datadogroku_setupIfNeeded()
    if (m.isConfigured = true)
        return
    end if
    ' 1. Cache injected fields
    fields = m.top.getFields()
    m.applicationId = fields.applicationId
    m.service = fields.service
    m.version = fields.version
    m.deviceName = fields.deviceName
    m.deviceModel = fields.deviceModel
    m.osVersion = fields.osVersion
    m.osVersionMajor = fields.osVersionMajor
    m.sessionSampleRate = fields.sessionSampleRate
    m.sessionScope = fields.sessionScope 'allow tests to inject a mock
    ' 2. Create session scope (skipped in tests if a mock was pre-injected)
    if (m.sessionScope = invalid)
        m.sessionScope = CreateObject("roSGNode", "datadogroku_RumSessionScope")
        m.sessionScope.setFields({
            parentScope: m.top
            sessionSampleRate: m.sessionSampleRate
        })
        m.top.sessionScope = m.sessionScope
    end if
    m.isConfigured = true
end sub