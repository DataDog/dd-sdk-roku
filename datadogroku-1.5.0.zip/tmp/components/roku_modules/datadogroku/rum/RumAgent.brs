' Unless explicitly stated otherwise all files in this repository are licensed under the Apache License Version 2.0.
' This product includes software developed at Datadog (https://www.datadoghq.com/).
' Copyright 2022-Today Datadog, Inc.
'import "pkg:/source/roku_modules/datadogroku/rum/rumRawEvents.bs"
'import "pkg:/source/roku_modules/datadogroku/rum/rumHelper.bs"
'import "pkg:/source/roku_modules/datadogroku/datadogSdk.bs"
'import "pkg:/source/roku_modules/datadogroku/internalLogger.bs"
' *****************************************************************
' * RumAgent: a background component listening for internal events
' *     to write relevant RUM Events to Datadog.
' *****************************************************************

' ----------------------------------------------------------------
' Initialize the component
' ----------------------------------------------------------------
sub init()
    datadogroku_ddLogThread("RumAgent.init()")
    m.port = createObject("roMessagePort")
    m.top.observeFieldScoped("startView", m.port)
    m.top.observeFieldScoped("stopView", m.port)
    m.top.observeFieldScoped("addAction", m.port)
    m.top.observeFieldScoped("addError", m.port)
    m.top.observeFieldScoped("addResource", m.port)
    m.top.observeFieldScoped("addConfigTelemetry", m.port)
    m.top.observeFieldScoped("addErrorTelemetry", m.port)
    m.top.observeFieldScoped("addDebugTelemetry", m.port)
    m.top.observeFieldScoped("startOperation", m.port)
    m.top.observeFieldScoped("succeedOperation", m.port)
    m.top.observeFieldScoped("failOperation", m.port)
    m.top.functionName = "datadogroku_rumAgentLoop"
end sub

' ----------------------------------------------------------------
' Main RumAgent loop
' ----------------------------------------------------------------
sub datadogroku_rumAgentLoop()
    datadogroku_ddLogThread("RumAgent.rumAgentLoop()")
    datadogroku_setup()
    while (true)
        msg = wait(0, m.port)
        msgType = type(msg)
        if (msgType = "roSGNodeEvent")
            fieldName = msg.getField()
            if (fieldName = "startView")
                __datadogroku_onStartView(msg.getData())
            else if (fieldName = "stopView")
                __datadogroku_onStopView(msg.getData())
            else if (fieldName = "addAction")
                __datadogroku_onAddAction(msg.getData())
            else if (fieldName = "addError")
                __datadogroku_onAddError(msg.getData())
            else if (fieldName = "addResource")
                __datadogroku_onAddResource(msg.getData())
            else if (fieldName = "addConfigTelemetry")
                __datadogroku_onAddConfigTelemetry(msg.getData())
            else if (fieldName = "addErrorTelemetry")
                __datadogroku_onAddErrorTelemetry(msg.getData())
            else if (fieldName = "addDebugTelemetry")
                __datadogroku_onAddDebugTelemetry(msg.getData())
            else if (fieldName = "startOperation")
                __datadogroku_onStartOperation(msg.getData())
            else if (fieldName = "succeedOperation")
                __datadogroku_onSucceedOperation(msg.getData())
            else if (fieldName = "failOperation")
                __datadogroku_onFailOperation(msg.getData())
            end if
        else
            datadogroku_ddLogWarning("Unexpected message " + msgType + ": " + FormatJson(msg))
        end if
    end while
end sub

sub datadogroku_setup()
    ' 1. Cache injected dependencies
    fields = m.top.getFields()
    m.uploader = fields.uploader
    m.writer = fields.writer 'allow tests to inject a mock
    m.rumScope = fields.rumScope 'allow tests to inject a mock
    m.telemetryScope = fields.telemetryScope 'allow tests to inject a mock
    m.applicationId = fields.applicationId
    m.service = fields.service
    m.version = fields.version
    m.deviceName = fields.deviceName
    m.deviceModel = fields.deviceModel
    m.osVersion = fields.osVersion
    m.osVersionMajor = fields.osVersionMajor
    m.sessionSampleRate = fields.sessionSampleRate
    m.env = fields.env
    m.site = fields.site
    m.lastExitOrTerminationReason = fields.lastExitOrTerminationReason
    m.configuration = fields.configuration
    ' 2. Create internal scopes
    m.instanceId = CreateObject("roDeviceInfo").GetRandomUUID()
    datadogroku_ddLogVerbose("RumAgent.instanceId:" + m.instanceId)
    m.global.setField("datadogRumContext", {
        applicationId: m.applicationId
        instanceId: m.instanceId
    })
    if (m.rumScope = invalid) 'skipped in tests (mock pre-injected)
        datadogroku_ddLogVerbose("Creating RumApplicationScope")
        m.rumScope = CreateObject("roSGNode", "datadogroku_RumApplicationScope")
        m.rumScope.setFields({
            applicationId: m.applicationId
            service: m.service
            version: m.version
            deviceName: m.deviceName
            deviceModel: m.deviceModel
            osVersion: m.osVersion
            osVersionMajor: m.osVersionMajor
            sessionSampleRate: m.sessionSampleRate
        })
        m.top.rumScope = m.rumScope
    end if
    if (m.telemetryScope = invalid) 'skipped in tests (mock pre-injected)
        datadogroku_ddLogVerbose("Creating RumTelemetryScope")
        m.telemetryScope = CreateObject("roSGNode", "datadogroku_RumTelemetryScope")
        m.top.telemetryScope = m.telemetryScope
    end if
    ' 3. Register our track on the shared uploader
    trackId = "rum_" + m.top.threadInfo().node.address
    tracks = (function(m)
            __bsConsequent = m.uploader.tracks
            if __bsConsequent <> invalid then
                return __bsConsequent
            else
                return {}
            end if
        end function)(m)
    tracks[trackId] = {
        url: datadogroku_getIntakeUrl(m.site, "rum")
        trackType: "rum"
        payloadPrefix: ""
        payloadPostfix: ""
        contentType: "text/plain;charset=UTF-8"
        queryParams: {
            ddsource: datadogroku_agentSource()
            ddtags: "sdk_version:" + datadogroku_sdkVersion() + ",env:" + m.env
        }
    }
    m.uploader.setFields({
        tracks: tracks
    })
    ' 4. Configure writer
    if (m.writer = invalid) 'skipped in tests (mock pre-injected)
        datadogroku_ddLogVerbose("Creating WriterTask")
        m.writer = CreateObject("roSGNode", "datadogroku_WriterTask")
        m.top.writer = m.writer
    end if
    m.writer.setFields({
        trackType: "rum"
        payloadSeparator: chr(10)
    })
    ' 5. One-time launch-side effects
    ' On RokuOS 13+, sendCrash reads the exit code from roAppManager.GetLastExitInfo()
    ' regardless of the launch-options value, so it must always be invoked.
    datadogroku_sendCrash((function(m)
            __bsConsequent = m.lastExitOrTerminationReason
            if __bsConsequent <> invalid then
                return __bsConsequent
            else
                return ""
            end if
        end function)(m))
    if (m.configuration <> invalid and m.configuration.Count() > 0)
        addConfigTelemetry(m.configuration)
    end if
end sub

' ----------------------------------------------------------------
' Starts a view
' @param name (string) the view name (human-readable)
' @param url (string) the view url (developer identifier)
' @param context (object) an assocarray of custom attributes to add to the view
' ----------------------------------------------------------------
sub startView(name as string, url as string, context = {} as object)
    m.top.startView = datadogroku_startViewEvent(name, url, context)
end sub

' ----------------------------------------------------------------
' Private: Handles startView field change event
' @param event (object) the startView event data
' ----------------------------------------------------------------
sub __datadogroku_onStartView(event as object)
    m.rumScope.callfunc("handleEvent", event, m.writer)
    m.rumScope.callfunc("handleEvent", datadogroku_keepAliveEvent(), m.writer)
end sub

' ----------------------------------------------------------------
' Stops a view
' @param name (string) the view name (human-readable)
' @param url (string) the view url (developer identifier)
' @param context (object) an assocarray of custom attributes to add to the view
' ----------------------------------------------------------------
sub stopView(name as string, url as string, context = {} as object)
    m.top.stopView = datadogroku_stopViewEvent(name, url, context)
end sub

' ----------------------------------------------------------------
' Private: Handles stopView field change event
' @param event (object) the stopView event data
' ----------------------------------------------------------------
sub __datadogroku_onStopView(event as object)
    m.rumScope.callfunc("handleEvent", event, m.writer)
end sub

' ----------------------------------------------------------------
' Adds an action
' @param action (object) the action to track
' @param context (object) an assocarray of custom attributes to add to the view
' ----------------------------------------------------------------
sub addAction(action as object, context = {} as object)
    m.top.addAction = datadogroku_addActionEvent(action, context)
end sub

' ----------------------------------------------------------------
' Private: Handles addAction field change event
' @param event (object) the addAction event data
' ----------------------------------------------------------------
sub __datadogroku_onAddAction(event as object)
    m.rumScope.callfunc("handleEvent", event, m.writer)
end sub

' ----------------------------------------------------------------
' Adds an error
' @param exception (object) the caught exception object
' @param context (object) an assocarray of custom attributes to add to the view
' ----------------------------------------------------------------
sub addError(exception as object, context = {} as object)
    m.top.addError = datadogroku_addErrorEvent(exception, context)
end sub

' ----------------------------------------------------------------
' Private: Handles addError field change event
' @param event (object) the addError event data
' ----------------------------------------------------------------
sub __datadogroku_onAddError(event as object)
    m.rumScope.callfunc("handleEvent", event, m.writer)
end sub

' ----------------------------------------------------------------
' Adds a resource
' @param resource (object) the tracked resource object (as retrieved from the roSystemLog)
' @param context (object) an assocarray of custom attributes to add to the view
' ----------------------------------------------------------------
sub addResource(resource as object, context = {} as object)
    m.top.addResource = datadogroku_addResourceEvent(resource, context)
end sub

' ----------------------------------------------------------------
' Private: Handles addResource field change event
' @param event (object) the addResource event data
' ----------------------------------------------------------------
sub __datadogroku_onAddResource(event as object)
    m.rumScope.callfunc("handleEvent", event, m.writer)
end sub

' ----------------------------------------------------------------
' Private: Handles sendCrash field change event
' @param lastExitOrTerminationReason (string) the last exit or termination reason
' ----------------------------------------------------------------
sub datadogroku_sendCrash(lastExitOrTerminationReason as string)
    crashReporter = CreateObject("roSGNode", "datadogroku_RumCrashReporterTask")
    exitReason = lastExitOrTerminationReason
    consoleLog = ""
    if (m.osVersionMajor.toInt() >= 13)
        lastExitInfo = createObject("roAppManager").GetLastExitInfo()
        if (lastExitInfo <> invalid)
            exitReason = lastExitInfo.exit_code
            consoleLog = lastExitInfo.console_log
        end if
    end if
    crashReporter.setFields({
        writer: m.writer
        lastExitOrTerminationReason: exitReason
        lastExitConsoleLog: consoleLog
        instanceId: m.instanceId
    })
    crashReporter.control = "RUN"
end sub

' ----------------------------------------------------------------
' Adds a telemetry config event
' @param configuration (object) the configuration information
' ----------------------------------------------------------------
sub addConfigTelemetry(configuration as object)
    m.top.addConfigTelemetry = datadogroku_addTelemetryConfigEvent(configuration)
end sub

' ----------------------------------------------------------------
' Private: Handles addConfigTelemetry field change event
' @param event (object) the addConfigTelemetry event data
' ----------------------------------------------------------------
sub __datadogroku_onAddConfigTelemetry(event as object)
    m.telemetryScope.callfunc("handleEvent", event, m.writer)
end sub

' ----------------------------------------------------------------
' Adds a telemetry error event
' @param exception (object) the caught exception object
' ----------------------------------------------------------------
sub addErrorTelemetry(exception as object)
    m.top.addErrorTelemetry = datadogroku_addTelemetryErrorEvent(exception)
end sub

' ----------------------------------------------------------------
' Private: Handles addErrorTelemetry field change event
' @param event (object) the addErrorTelemetry event data
' ----------------------------------------------------------------
sub __datadogroku_onAddErrorTelemetry(event as object)
    m.telemetryScope.callfunc("handleEvent", event, m.writer)
end sub

' ----------------------------------------------------------------
' Adds a telemetry debug event
' @param message (string) the message to send
' ----------------------------------------------------------------
sub addDebugTelemetry(message as string)
    m.top.addDebugTelemetry = datadogroku_addTelemetryDebugEvent(message)
end sub

' ----------------------------------------------------------------
' Private: Handles addDebugTelemetry field change event
' @param event (object) the addDebugTelemetry event data
' ----------------------------------------------------------------
sub __datadogroku_onAddDebugTelemetry(event as object)
    m.telemetryScope.callfunc("handleEvent", event, m.writer)
end sub

' ----------------------------------------------------------------
' Starts a feature operation
' @param name (string) the operation name (e.g.: "login", "checkout")
' @param operationKey (dynamic) the operation key for distinguishing parallel
'     operations, or invalid for unkeyed operations
' @param context (object) an assocarray of custom attributes to add to the event
' ----------------------------------------------------------------
sub startOperation(name as string, operationKey = invalid as dynamic, context = {} as object)
    if (not __datadogroku_isValidOperationName(name))
        datadogroku_ddLogError("RumAgent: startOperation called with blank name, ignoring")
        return
    end if
    if (not __datadogroku_isValidOperationKey(operationKey))
        datadogroku_ddLogError("RumAgent: startOperation called with blank operationKey, ignoring")
        return
    end if
    m.top.startOperation = datadogroku_startFeatureOperationEvent(name, operationKey, context)
end sub

' ----------------------------------------------------------------
' Private: Handles startOperation field change event
' @param event (object) the startOperation event data
' ----------------------------------------------------------------
sub __datadogroku_onStartOperation(event as object)
    m.rumScope.callfunc("handleEvent", event, m.writer)
end sub

' ----------------------------------------------------------------
' Succeeds a feature operation
' @param name (string) the operation name (e.g.: "login", "checkout")
' @param operationKey (dynamic) the operation key for distinguishing parallel
'     operations, or invalid for unkeyed operations
' @param context (object) an assocarray of custom attributes to add to the event
' ----------------------------------------------------------------
sub succeedOperation(name as string, operationKey = invalid as dynamic, context = {} as object)
    if (not __datadogroku_isValidOperationName(name))
        datadogroku_ddLogError("RumAgent: succeedOperation called with blank name, ignoring")
        return
    end if
    if (not __datadogroku_isValidOperationKey(operationKey))
        datadogroku_ddLogError("RumAgent: succeedOperation called with blank operationKey, ignoring")
        return
    end if
    m.top.succeedOperation = datadogroku_succeedFeatureOperationEvent(name, operationKey, context)
end sub

' ----------------------------------------------------------------
' Private: Handles succeedOperation field change event
' @param event (object) the succeedOperation event data
' ----------------------------------------------------------------
sub __datadogroku_onSucceedOperation(event as object)
    m.rumScope.callfunc("handleEvent", event, m.writer)
end sub

' ----------------------------------------------------------------
' Fails a feature operation
' @param name (string) the operation name (e.g.: "login", "checkout")
' @param failureReason (string) the failure reason (use "error", "abandoned", or "other")
' @param operationKey (dynamic) the operation key for distinguishing parallel
'     operations, or invalid for unkeyed operations
' @param context (object) an assocarray of custom attributes to add to the event
' ----------------------------------------------------------------
sub failOperation(name as string, failureReason as string, operationKey = invalid as dynamic, context = {} as object)
    if (not __datadogroku_isValidOperationName(name))
        datadogroku_ddLogError("RumAgent: failOperation called with blank name, ignoring")
        return
    end if
    if (not __datadogroku_isValidOperationKey(operationKey))
        datadogroku_ddLogError("RumAgent: failOperation called with blank operationKey, ignoring")
        return
    end if
    if (not __datadogroku_isValidFailureReason(failureReason))
        datadogroku_ddLogError("RumAgent: failOperation called with invalid failureReason '" + failureReason + "', ignoring")
        return
    end if
    m.top.failOperation = datadogroku_failFeatureOperationEvent(name, operationKey, failureReason, context)
end sub

' ----------------------------------------------------------------
' Private: Handles failOperation field change event
' @param event (object) the failOperation event data
' ----------------------------------------------------------------
sub __datadogroku_onFailOperation(event as object)
    m.rumScope.callfunc("handleEvent", event, m.writer)
end sub

' ----------------------------------------------------------------
' Returns true if the operation name is valid (non-blank after trimming)
' @param name (string) the operation name to validate
' @return (boolean) whether the name is valid
' ----------------------------------------------------------------
function __datadogroku_isValidOperationName(name as string) as boolean
    return name.Trim().Len() > 0
end function

' ----------------------------------------------------------------
' Returns true if the operationKey is valid:
'   - invalid is VALID (means unkeyed operation)
'   - non-empty string after trimming is VALID
'   - empty or whitespace-only string is INVALID
'   - non-string, non-invalid values are INVALID
' @param operationKey (dynamic) the operation key to validate
' @return (boolean) whether the key is valid
' ----------------------------------------------------------------
function __datadogroku_isValidOperationKey(operationKey as dynamic) as boolean
    if (operationKey = invalid)
        return true
    end if
    if (type(operationKey) = "roString" or type(operationKey) = "String")
        return operationKey.Trim().Len() > 0
    end if
    ' Non-string, non-invalid values are invalid
    return false
end function

' ----------------------------------------------------------------
' Returns true if the failureReason is a known FailureReason value
' @param failureReason (string) the failure reason to validate
' @return (boolean) whether the failure reason is valid
' ----------------------------------------------------------------
function __datadogroku_isValidFailureReason(reason as string) as boolean
    return (reason = "error" or reason = "abandoned" or reason = "other")
end function