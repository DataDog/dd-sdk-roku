' Unless explicitly stated otherwise all files in this repository are licensed under the Apache License Version 2.0.
' This product includes software developed at Datadog (https://www.datadoghq.com/).
' Copyright 2022-Today Datadog, Inc.
'import "pkg:/source/roku_modules/datadogroku/datadogSdk.bs"
'import "pkg:/source/roku_modules/datadogroku/internalLogger.bs"
'import "pkg:/source/roku_modules/datadogroku/timeUtils.bs"
'import "pkg:/source/roku_modules/datadogroku/logs/logStatus.bs"
' *****************************************************************
' * LogsAgent: a component exposing logging APIs that write
' *     Log Events to Datadog.
' *****************************************************************

' ----------------------------------------------------------------
' Initialize the component
' ----------------------------------------------------------------
sub init()
    datadogroku_ddLogThread("LogsAgent.init()")
end sub

' ----------------------------------------------------------------
' Adds a ok log
' @param message (string) the log message
' @param attributes (object) additional custom attributes
' ----------------------------------------------------------------
sub logOk(message as string, attributes as object)
    datadogroku_ddLogThread("LogsAgent.logOk()")
    datadogroku_ddLogVerbose("[ OK ] " + message)
    datadogroku_sendLog("ok", message, attributes)
end sub

' ----------------------------------------------------------------
' Adds a debug log
' @param message (string) the log message
' @param attributes (object) additional custom attributes
' ----------------------------------------------------------------
sub logDebug(message as string, attributes as object)
    datadogroku_ddLogThread("LogsAgent.logDebug()")
    datadogroku_ddLogVerbose("[ DEBUG ] " + message)
    datadogroku_sendLog("debug", message, attributes)
end sub

' ----------------------------------------------------------------
' Adds a info log
' @param message (string) the log message
' @param attributes (object) additional custom attributes
' ----------------------------------------------------------------
sub logInfo(message as string, attributes as object)
    datadogroku_ddLogThread("LogsAgent.logInfo()")
    datadogroku_ddLogInfo("[ INFO ] " + message)
    datadogroku_sendLog("info", message, attributes)
end sub

' ----------------------------------------------------------------
' Adds a notice log
' @param message (string) the log message
' @param attributes (object) additional custom attributes
' ----------------------------------------------------------------
sub logNotice(message as string, attributes as object)
    datadogroku_ddLogThread("LogsAgent.logNotice()")
    datadogroku_ddLogInfo("[ NOTICE ] " + message)
    datadogroku_sendLog("notice", message, attributes)
end sub

' ----------------------------------------------------------------
' Adds a warn log
' @param message (string) the log message
' @param attributes (object) additional custom attributes
' ----------------------------------------------------------------
sub logWarn(message as string, attributes as object)
    datadogroku_ddLogThread("LogsAgent.logWarn()")
    datadogroku_ddLogWarning("[ WARN ] " + message)
    datadogroku_sendLog("warn", message, attributes)
end sub

' ----------------------------------------------------------------
' Adds a error log
' @param message (string) the log message
' @param attributes (object) additional custom attributes
' ----------------------------------------------------------------
sub logError(message as string, attributes as object)
    datadogroku_ddLogThread("LogsAgent.logError()")
    datadogroku_ddLogError("[ ERROR ] " + message)
    datadogroku_sendLog("error", message, attributes)
end sub

' ----------------------------------------------------------------
' Adds a critical log
' @param message (string) the log message
' @param attributes (object) additional custom attributes
' ----------------------------------------------------------------
sub logCritical(message as string, attributes as object)
    datadogroku_ddLogThread("LogsAgent.logCritical()")
    datadogroku_ddLogError("[ CRITICAL ] " + message)
    datadogroku_sendLog("critical", message, attributes)
end sub

' ----------------------------------------------------------------
' Adds a alert log
' @param message (string) the log message
' @param attributes (object) additional custom attributes
' ----------------------------------------------------------------
sub logAlert(message as string, attributes as object)
    datadogroku_ddLogThread("LogsAgent.logAlert()")
    datadogroku_ddLogError("[ ALERT ] " + message)
    datadogroku_sendLog("alert", message, attributes)
end sub

' ----------------------------------------------------------------
' Adds a emergency log
' @param message (string) the log message
' @param attributes (object) additional custom attributes
' ----------------------------------------------------------------
sub logEmergency(message as string, attributes as object)
    datadogroku_ddLogThread("LogsAgent.logEmergency()")
    datadogroku_ddLogError("[ EMERGENCY ] " + message)
    datadogroku_sendLog("emergency", message, attributes)
end sub

' ----------------------------------------------------------------
' Sends a log event
' @param status (LogStatus) the status of the log
' @param message (string) the log message
' @param attributes (object) additional custom attributes
' ----------------------------------------------------------------
sub datadogroku_sendLog(status as object, message as string, attributes as object)
    timestamp& = datadogroku_getTimestamp()
    datadogroku_setupIfNeeded()
    logEvent = {
        date: timestamp&
        ddtags: "env:" + m.env + ",version:" + m.version
        message: message
        status: status
        service: m.service
        usr: m.userInfo
        device: {
            type: "tv"
            name: m.deviceName
            model: m.deviceModel
            brand: "Roku"
        }
        os: {
            name: "Roku"
            version: m.osVersion
            version_major: m.osVersionMajor
        }
        logger: {
            thread_name: m.top.threadInfo().currentThread.name
            version: datadogroku_sdkVersion()
        }
    }
    logEvent.append(attributes)
    if (m.ddContext <> invalid)
        logEvent.append(m.ddContext)
    end if
    rumContext = m.rumContext
    if (rumContext <> invalid)
        logEvent["application_id"] = rumContext.applicationId
        logEvent["session_id"] = rumContext.sessionId
        logEvent["view"] = {
            id: rumContext.viewId
        }
        logEvent["user_action"] = {
            id: rumContext.actionId
        }
    end if
    m.writer.writeEvent = FormatJson(logEvent)
end sub

sub datadogroku_setupIfNeeded()
    if (m.isConfigured = true)
        return
    end if
    ' 1. Cache injected dependencies
    fields = m.top.getFields()
    m.uploader = fields.uploader
    m.writer = fields.writer 'allow tests to inject a mock
    m.service = fields.service
    m.version = fields.version
    m.env = fields.env
    m.deviceName = fields.deviceName
    m.deviceModel = fields.deviceModel
    m.osVersion = fields.osVersion
    m.osVersionMajor = fields.osVersionMajor
    m.site = fields.site
    ' 2. Configure writer
    if (m.writer = invalid) 'skipped in tests (mock pre-injected)
        datadogroku_ddLogVerbose("Creating WriterTask")
        m.writer = CreateObject("roSGNode", "datadogroku_WriterTask")
        m.top.writer = m.writer
    end if
    m.writer.setFields({
        trackType: "logs"
        payloadSeparator: ","
    })
    ' 3. Register our track on the shared uploader
    trackId = "logs_" + m.top.threadInfo().node.address
    tracks = (function(m)
            __bsConsequent = m.uploader.tracks
            if __bsConsequent <> invalid then
                return __bsConsequent
            else
                return {}
            end if
        end function)(m)
    tracks[trackId] = {
        url: datadogroku_getIntakeUrl(m.site, "logs")
        trackType: "logs"
        payloadPrefix: "["
        payloadPostfix: "]"
        contentType: "application/json"
        queryParams: {
            ddsource: datadogroku_agentSource()
        }
    }
    m.uploader.setFields({
        tracks: tracks
    })
    ' 4. Cache the global context locally, kept in sync via observers
    m.global.observeFieldScoped("datadogUserInfo", "datadogroku_onUserInfoChanged")
    m.global.observeFieldScoped("datadogContext", "datadogroku_onContextChanged")
    m.global.observeFieldScoped("datadogRumContext", "datadogroku_onRumContextChanged")
    m.userInfo = m.global.datadogUserInfo
    m.ddContext = m.global.datadogContext
    m.rumContext = m.global.datadogRumContext
    m.isConfigured = true
end sub

sub datadogroku_onUserInfoChanged(event as object)
    m.userInfo = event.getData()
end sub

sub datadogroku_onContextChanged(event as object)
    m.ddContext = event.getData()
end sub

sub datadogroku_onRumContextChanged(event as object)
    m.rumContext = event.getData()
end sub