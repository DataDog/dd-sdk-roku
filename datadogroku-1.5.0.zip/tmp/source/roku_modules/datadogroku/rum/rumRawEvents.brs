' Unless explicitly stated otherwise all files in this repository are licensed under the Apache License Version 2.0.
' This product includes software developed at Datadog (https://www.datadoghq.com/).
' Copyright 2022-Today Datadog, Inc.
'import "pkg:/source/roku_modules/datadogroku/timeUtils.bs"
'*****************************************************************
'* Utilities to generate internal RUM events
'*****************************************************************

' ----------------------------------------------------------------
' @param viewName (string) the view name (human-readable)
' @param viewUrl (string) the view url (developer identifier)
' @param context (object) an assocarray of custom attributes to add to the view
' @return (object) an event describing a startView action
' ----------------------------------------------------------------
function datadogroku_startViewEvent(viewName as string, viewUrl as string, context as object) as object
    return {
        eventType: "startView"
        viewName: viewName
        viewUrl: viewUrl
        context: context
    }
end function

' ----------------------------------------------------------------
' @param viewName (string) the view name (human-readable)
' @param viewUrl (string) the view url (developer identifier)
' @param context (object) an assocarray of custom attributes to add to the view
' @return (object) an event describing a stopView action
' ----------------------------------------------------------------
function datadogroku_stopViewEvent(viewName as string, viewUrl as string, context as object) as object
    return {
        eventType: "stopView"
        viewName: viewName
        viewUrl: viewUrl
        context: context
    }
end function

' ----------------------------------------------------------------
' @param action (object) the action to track
' @param context (object) an assocarray of custom attributes to add to the view
' @return (object) an event describing an addAction action
' ----------------------------------------------------------------
function datadogroku_addActionEvent(action as object, context as object) as object
    return {
        eventType: "addAction"
        action: action
        context: context
    }
end function

' ----------------------------------------------------------------
' @param exception (object) the caught exception
' @param context (object) an assocarray of custom attributes to add to the view
' @return (object) an event describing an addError action
' ----------------------------------------------------------------
function datadogroku_addErrorEvent(exception as object, context as object) as object
    return {
        eventType: "addError"
        exception: exception
        context: context
    }
end function

' ----------------------------------------------------------------
' @param resource (object) the resource object
' @param context (object) an assocarray of custom attributes to add to the view
' @return (object) an event describing an addResource action
' ----------------------------------------------------------------
function datadogroku_addResourceEvent(resource as object, context as object) as object
    return {
        eventType: "addResource"
        resource: resource
        context: context
    }
end function

' ----------------------------------------------------------------
' @return (object) a keep alive
' ----------------------------------------------------------------
function datadogroku_keepAliveEvent() as object
    return {
        eventType: "keepAlive"
    }
end function

' ----------------------------------------------------------------
' @param configuration (object) the configuration object
' @return (object) an event describing an addTelemetryConfigEvent action
' ----------------------------------------------------------------
function datadogroku_addTelemetryConfigEvent(configuration as object) as object
    return {
        eventType: "telemetryConfig"
        configuration: configuration
    }
end function

' ----------------------------------------------------------------
' @param exception (object) the exception object
' @return (object) an event describing an addTelemetryErrorEvent action
' ----------------------------------------------------------------
function datadogroku_addTelemetryErrorEvent(exception as object) as object
    return {
        eventType: "telemetryError"
        exception: exception
    }
end function

' ----------------------------------------------------------------
' @param message (string) the message
' @return (object) an event describing an addTelemetryDebugEvent action
' ----------------------------------------------------------------
function datadogroku_addTelemetryDebugEvent(message as string) as object
    return {
        eventType: "telemetryDebug"
        message: message
    }
end function

' ----------------------------------------------------------------
' @param name (string) the operation name (e.g.: "Login", "Checkout")
' @param operationKey (dynamic) the operation key for distinguishing parallel operations, or invalid for unkeyed
' @param context (object) an assocarray of custom attributes to add to the event
' @return (object) an event describing a startFeatureOperation action
' ----------------------------------------------------------------
function datadogroku_startFeatureOperationEvent(name as string, operationKey as dynamic, context as object) as object
    return {
        eventType: "startFeatureOperation"
        name: name
        timestamp: datadogroku_getTimestamp()
        operationKey: operationKey
        vitalId: CreateObject("roDeviceInfo").GetRandomUUID()
        context: context
    }
end function

' ----------------------------------------------------------------
' @param name (string) the operation name (e.g.: "Login", "Checkout")
' @param operationKey (dynamic) the operation key for distinguishing parallel operations, or invalid for unkeyed
' @param context (object) an assocarray of custom attributes to add to the event
' @return (object) an event describing a succeedFeatureOperation action
' ----------------------------------------------------------------
function datadogroku_succeedFeatureOperationEvent(name as string, operationKey as dynamic, context as object) as object
    return {
        eventType: "stopFeatureOperation"
        name: name
        timestamp: datadogroku_getTimestamp()
        operationKey: operationKey
        vitalId: CreateObject("roDeviceInfo").GetRandomUUID()
        context: context
    }
end function

' ----------------------------------------------------------------
' @param name (string) the operation name (e.g.: "Login", "Checkout")
' @param operationKey (dynamic) the operation key for distinguishing parallel operations, or invalid for unkeyed
' @param failureReason (string) the failure reason (use FailureReason enum values: "error", "abandoned", "other")
' @param context (object) an assocarray of custom attributes to add to the event
' @return (object) an event describing a failFeatureOperation action
' ----------------------------------------------------------------
function datadogroku_failFeatureOperationEvent(name as string, operationKey as dynamic, failureReason as string, context as object) as object
    return {
        eventType: "stopFeatureOperation"
        name: name
        timestamp: datadogroku_getTimestamp()
        operationKey: operationKey
        failureReason: failureReason
        vitalId: CreateObject("roDeviceInfo").GetRandomUUID()
        context: context
    }
end function
' ----------------------------------------------------------------
' RawEvent: enum listing all the possible events handled by RUM scopes
' ----------------------------------------------------------------

' ----------------------------------------------------------------
' VitalStepType: enum listing the step types for vital operation events
' Values match the schema-defined string equivalents from vital-operation-step-schema.json
' ----------------------------------------------------------------

' ----------------------------------------------------------------
' FailureReason: enum listing the failure reasons for vital operation events
' Values match the schema-defined string equivalents from vital-operation-step-schema.json
' ----------------------------------------------------------------
