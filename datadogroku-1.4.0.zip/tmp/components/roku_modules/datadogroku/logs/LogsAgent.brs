' Unless explicitly stated otherwise all files in this repository are licensed under the Apache License Version 2.0.
' This product includes software developed at Datadog (https://www.datadoghq.com/).
' Copyright 2022-Today Datadog, Inc.
'import "pkg:/source/roku_modules/datadogroku/datadogSdk.bs"
'import "pkg:/source/roku_modules/datadogroku/internalLogger.bs"
'import "pkg:/source/roku_modules/datadogroku/timeUtils.bs"
'import "pkg:/source/roku_modules/datadogroku/logs/logStatus.bs"
' *****************************************************************
' * RumAgent: a background component listening for internal events
' *     to write relevant RUM Event to Datadog.
' *****************************************************************

' ----------------------------------------------------------------
' Initialize the component
' ----------------------------------------------------------------
sub init()
    datadogroku_ddLogThread("LogsAgent.init()")
end sub

' ----------------------------------------------------------------
' Adds a ok log
' @param message (string) the log message
' @param attributes (object) additional custom attributes
' ----------------------------------------------------------------
sub logOk(message as string, attributes as object)
    datadogroku_ddLogThread("LogsAgent.logOk()")
    datadogroku_ddLogVerbose("[ OK ] " + message)
    datadogroku_sendLog("ok", message, attributes)
end sub

' ----------------------------------------------------------------
' Adds a debug log
' @param message (string) the log message
' @param attributes (object) additional custom attributes
' ----------------------------------------------------------------
sub logDebug(message as string, attributes as object)
    datadogroku_ddLogThread("LogsAgent.logDebug()")
    datadogroku_ddLogVerbose("[ DEBUG ] " + message)
    datadogroku_sendLog("debug", message, attributes)
end sub

' ----------------------------------------------------------------
' Adds a info log
' @param message (string) the log message
' @param attributes (object) additional custom attributes
' ----------------------------------------------------------------
sub logInfo(message as string, attributes as object)
    datadogroku_ddLogThread("LogsAgent.logInfo()")
    datadogroku_ddLogInfo("[ INFO ] " + message)
    datadogroku_sendLog("info", message, attributes)
end sub

' ----------------------------------------------------------------
' Adds a notice log
' @param message (string) the log message
' @param attributes (object) additional custom attributes
' ----------------------------------------------------------------
sub logNotice(message as string, attributes as object)
    datadogroku_ddLogThread("LogsAgent.logNotice()")
    datadogroku_ddLogInfo("[ NOTICE ] " + message)
    datadogroku_sendLog("notice", message, attributes)
end sub

' ----------------------------------------------------------------
' Adds a warn log
' @param message (string) the log message
' @param attributes (object) additional custom attributes
' ----------------------------------------------------------------
sub logWarn(message as string, attributes as object)
    datadogroku_ddLogThread("LogsAgent.logWarn()")
    datadogroku_ddLogWarning("[ WARN ] " + message)
    datadogroku_sendLog("warn", message, attributes)
end sub

' ----------------------------------------------------------------
' Adds a error log
' @param message (string) the log message
' @param attributes (object) additional custom attributes
' ----------------------------------------------------------------
sub logError(message as string, attributes as object)
    datadogroku_ddLogThread("LogsAgent.logError()")
    datadogroku_ddLogError("[ ERROR ] " + message)
    datadogroku_sendLog("error", message, attributes)
end sub

' ----------------------------------------------------------------
' Adds a critical log
' @param message (string) the log message
' @param attributes (object) additional custom attributes
' ----------------------------------------------------------------
sub logCritical(message as string, attributes as object)
    datadogroku_ddLogThread("LogsAgent.logCritical()")
    datadogroku_ddLogError("[ CRITICAL ] " + message)
    datadogroku_sendLog("critical", message, attributes)
end sub

' ----------------------------------------------------------------
' Adds a alert log
' @param message (string) the log message
' @param attributes (object) additional custom attributes
' ----------------------------------------------------------------
sub logAlert(message as string, attributes as object)
    datadogroku_ddLogThread("LogsAgent.logAlert()")
    datadogroku_ddLogError("[ ALERT ] " + message)
    datadogroku_sendLog("alert", message, attributes)
end sub

' ----------------------------------------------------------------
' Adds a emergency log
' @param message (string) the log message
' @param attributes (object) additional custom attributes
' ----------------------------------------------------------------
sub logEmergency(message as string, attributes as object)
    datadogroku_ddLogThread("LogsAgent.logEmergency()")
    datadogroku_ddLogError("[ EMERGENCY ] " + message)
    datadogroku_sendLog("emergency", message, attributes)
end sub

' ----------------------------------------------------------------
' Sends a log event
' @param status (LogStatus) the status of the log
' @param message (string) the log message
' @param attributes (object) additional custom attributes
' ----------------------------------------------------------------
sub datadogroku_sendLog(status as object, message as string, attributes as object)
    timestamp& = datadogroku_getTimestamp()
    datadogroku_ensureSetup()
    logEvent = {
        date: timestamp&
        ddtags: "env:" + m.top.env + ",version:" + m.top.version
        message: message
        status: status
        service: m.top.service
        usr: m.global.datadogUserInfo
        device: {
            type: "tv"
            name: m.top.deviceName
            model: m.top.deviceModel
            brand: "Roku"
        }
        os: {
            name: "Roku"
            version: m.top.osVersion
            version_major: m.top.osVersionMajor
        }
        logger: {
            thread_name: m.top.threadInfo().currentThread.name
            version: datadogroku_sdkVersion()
        }
    }
    for each key in attributes
        logEvent[key] = attributes[key]
    end for
    if (m.global.datadogContext <> invalid)
        for each key in m.global.datadogContext
            logEvent[key] = m.global.datadogContext[key]
        end for
    end if
    if (m.global.datadogRumContext <> invalid)
        logEvent["application_id"] = m.global.datadogRumContext.applicationId
        logEvent["session_id"] = m.global.datadogRumContext.sessionId
        logEvent["view"] = {
            id: m.global.datadogRumContext.viewId
        }
        logEvent["user_action"] = {
            id: m.global.datadogRumContext.actionId
        }
    end if
    m.top.writer.writeEvent = FormatJson(logEvent)
end sub

' ----------------------------------------------------------------
' Ensure all dependencies are present (from DI or generated)
' ----------------------------------------------------------------
sub datadogroku_ensureSetup()
    datadogroku_ensureUploader()
    datadogroku_ensureWriter()
end sub

' ----------------------------------------------------------------
' Sets the uploader node from the top node's field,
' or instantiate one.
' ----------------------------------------------------------------
sub datadogroku_ensureUploader()
    uploader = m.top.uploader
    if (m.top.uploader = invalid)
        uploader = CreateObject("roSGNode", "datadogroku_MultiTrackUploaderTask")
    end if
    trackId = "logs_" + m.top.threadInfo().node.address
    tracks = (function(uploader)
            __bsConsequent = uploader.tracks
            if __bsConsequent <> invalid then
                return __bsConsequent
            else
                return {}
            end if
        end function)(uploader)
    tracks[trackId] = {
        url: datadogroku_getIntakeUrl(m.top.site, "logs")
        trackType: "logs"
        payloadPrefix: "["
        payloadPostfix: "]"
        contentType: "application/json"
        queryParams: {
            ddsource: datadogroku_agentSource()
        }
    }
    uploader.tracks = tracks
    uploader.clientToken = m.top.clientToken
    m.top.uploader = uploader
end sub

' ----------------------------------------------------------------
' Sets the writer node from the top node's field,
' or instantiate one.
' ----------------------------------------------------------------
sub datadogroku_ensureWriter()
    writer = m.top.writer
    if (writer = invalid)
        datadogroku_ddLogVerbose("Creating WriterTask")
        writer = CreateObject("roSGNode", "datadogroku_WriterTask")
    end if
    writer.trackType = "logs"
    writer.payloadSeparator = ","
    m.top.writer = writer
end sub