' Unless explicitly stated otherwise all files in this repository are licensed under the Apache License Version 2.0.
' This product includes software developed at Datadog (https://www.datadoghq.com/).
' Copyright 2022-Today Datadog, Inc.
' ****************************************************************
' * RumApplicationScope: handles the Application level,
' * delegates most to the children
' ****************************************************************

' ----------------------------------------------------------------
' Initialize the component
' ----------------------------------------------------------------
sub init()
end sub

' ----------------------------------------------------------------
' Returns the current context from this scope
' @param _ph (dynamic) no-op argument to avoid random crash on older Roku devices
' @returns (object) the current context
' ----------------------------------------------------------------
function getRumContext(_ph as dynamic) as object
    return {
        applicationId: m.top.applicationId
        service: m.top.service
        applicationVersion: m.top.version
        deviceName: m.top.deviceName
        deviceModel: m.top.deviceModel
        osVersion: m.top.osVersion
        osVersionMajor: m.top.osVersionMajor
    }
end function

' ----------------------------------------------------------------
' Handles an internal event
' @param event (object) the event to handle
' @param writer (object) the writer node (see WriterTask component)
' ----------------------------------------------------------------
sub handleEvent(event as object, writer as object)
    datadogroku_ensureSessionScope()
    m.top.sessionScope.callfunc("handleEvent", event, writer)
end sub

' ----------------------------------------------------------------
' Returns information about whether the current scope can handle more events or not
' @param _ph (dynamic) no-op argument to avoid random crash on older Roku devices
' @return (boolean) `true` if this scope expects more event, `false` if it's complete
' ----------------------------------------------------------------
function isActive(_ph as dynamic) as boolean
    ' TODO
    return invalid
end function

' ----------------------------------------------------------------
' Sets the internal session scope from the top node's field,
' or instantiate one.
' ----------------------------------------------------------------
sub datadogroku_ensureSessionScope()
    if (m.top.sessionScope = invalid)
        m.top.sessionScope = CreateObject("roSGNode", "datadogroku_RumSessionScope")
        m.top.sessionScope.parentScope = m.top
        m.top.sessionScope.sessionSampleRate = m.top.sessionSampleRate
    end if
end sub