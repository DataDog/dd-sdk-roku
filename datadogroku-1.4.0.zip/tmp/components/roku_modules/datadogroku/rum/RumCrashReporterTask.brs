' Unless explicitly stated otherwise all files in this repository are licensed under the Apache License Version 2.0.
' This product includes software developed at Datadog (https://www.datadoghq.com/).
' Copyright 2022-Today Datadog, Inc.
'import "pkg:/source/roku_modules/datadogroku/fileUtils.bs"
' *****************************************************************
' * RumCrashReporterTask : a node capable of writing data to a file on disk
' *****************************************************************
'import "pkg:/source/roku_modules/datadogroku/rum/rumHelper.bs"

' ----------------------------------------------------------------
' Initialize the component
' ----------------------------------------------------------------
sub init()
    datadogroku_ddLogThread("RumCrashReporterTask.init()")
    m.port = createObject("roMessagePort")
    m.top.functionName = "datadogroku_sendCrashReport"
end sub

' ----------------------------------------------------------------
' Reads the last known view event and send the crash report
' ----------------------------------------------------------------
sub datadogroku_sendCrashReport()
    datadogroku_ddLogThread("RumCrashReporterTask.sendCrashReport()")
    currentSessionlastViewEventFilePath = datadogroku_lastViewEventFilePath(m.top.instanceId)
    m.lastExitOrTerminationReason = m.top.lastExitOrTerminationReason
    ignoredExitEvents = (function(m)
            __bsConsequent = m.global.datadogIgnoredExitEvents
            if __bsConsequent <> invalid then
                return __bsConsequent
            else
                return []
            end if
        end function)(m)
    keep = true
    if (m.lastExitOrTerminationReason = "")
        datadogroku_ddLogInfo("Last exit status is empty, ignoring")
        keep = false
    else
        for each status in ignoredExitEvents
            if (m.lastExitOrTerminationReason = status)
                keep = false
                exit for
            end if
        end for
    end if
    if (not keep)
        datadogroku_ddLogInfo("Last exit status " + m.lastExitOrTerminationReason + " is not a crash, ignoring")
    end if
    folderPath = datadogroku_trackFolderPath("rum")
    filenames = ListDir(folderPath)
    for each filename in filenames
        filePath = folderPath + "/" + filename
        datadogroku_ddLogVerbose("RumCrashReporterTask, checking file: " + filename)
        if (filePath = currentSessionlastViewEventFilePath)
            datadogroku_ddLogVerbose("Ignoring current session file: " + filename)
        else if (filename.Left(10) = "_last_view")
            if (keep)
                datadogroku_ddLogVerbose("Found last view file " + filePath)
                datadogroku_sendCrashReportFromViewEventFile(filePath)
            end if
            datadogroku_ddLogVerbose("Deleting file " + filePath)
            DeleteFile(filePath)
        end if
    end for
    datadogroku_ddLogVerbose("RumCrashReporterTask, all checks done")
end sub

' ----------------------------------------------------------------
' Sends a crash report linked to the view stored in the given path
' @param filepath (string) the path to the file holding the last known view event
' ----------------------------------------------------------------
sub datadogroku_sendCrashReportFromViewEventFile(filepath as string)
    datadogroku_ddLogVerbose("Reading file " + filepath)
    lastViewEventJson = ReadAsciiFile(filepath)
    if (lastViewEventJson = "" or lastViewEventJson = invalid)
        datadogroku_ddLogWarning("A crash was detected but the last known view is empty, ignoring")
        return
    end if
    datadogroku_ddLogVerbose("Parsing event from " + filepath)
    lastViewEvent = ParseJson(lastViewEventJson)
    if (lastViewEvent = invalid or lastViewEvent._dd = invalid or lastViewEvent.view = invalid or lastViewEvent.date = invalid)
        datadogroku_ddLogError("A crash was detected but the last view event is invalid")
        datadogroku_ddLogError(lastViewEventJson)
        return
    end if
    timeSpentNs& = ((function(lastViewEvent)
            __bsConsequent = lastViewEvent.view.time_spent
            if __bsConsequent <> invalid then
                return __bsConsequent
            else
                return 0
            end if
        end function)(lastViewEvent)) + datadogroku_millisToNanos(100) ' 100 ms after last known timestamp
    timeSpentMs& = datadogroku_nanosToMillis(timeSpentNs&)
    timestamp& = timeSpentMs& + lastViewEvent.date
    crashEvent = {
        _dd: {
            format_version: 2
            session: {
                plan: 1
            }
        }
        application: {
            id: lastViewEvent.application.id
        }
        context: m.global.datadogContext
        date: timestamp&
        error: {
            id: CreateObject("roDeviceInfo").GetRandomUUID()
            is_crash: true
            message: "Channel stopped unexpectedly"
            source: "source"
            source_type: datadogroku_agentSource()
            stack: m.top.lastExitConsoleLog
            type: m.lastExitOrTerminationReason
        }
        service: lastViewEvent.service
        session: {
            has_replay: false
            id: lastViewEvent.session.id
            type: "user"
        }
        source: datadogroku_agentSource()
        type: "error"
        usr: lastViewEvent.usr
        version: lastViewEvent.version
        view: {
            id: lastViewEvent.view.id
            url: lastViewEvent.view.url
            name: lastViewEvent.view.name
        }
    }
    datadogroku_ddLogInfo("RumCrashReporterTask, writing crash")
    m.top.writer.writeEvent = FormatJson(crashEvent)
    sleep(50)
    lastViewEvent._dd.document_version = ((function(lastViewEvent)
            __bsConsequent = lastViewEvent._dd.document_version
            if __bsConsequent <> invalid then
                return __bsConsequent
            else
                return 0
            end if
        end function)(lastViewEvent)) + 1
    lastViewEvent.view.error = {
        count: ((function(lastViewEvent)
                __bsConsequent = lastViewEvent.view.error.count
                if __bsConsequent <> invalid then
                    return __bsConsequent
                else
                    return 0
                end if
            end function)(lastViewEvent)) + 1
    }
    lastViewEvent.view.crash = {
        count: 1
    }
    lastViewEvent.view.time_spent = timeSpentNs&
    datadogroku_ddLogInfo("RumCrashReporterTask, writing view update")
    m.top.writer.writeEvent = FormatJson(lastViewEvent)
end sub