' Unless explicitly stated otherwise all files in this repository are licensed under the Apache License Version 2.0.
' This product includes software developed at Datadog (https://www.datadoghq.com/).
' Copyright 2022-Today Datadog, Inc.
'import "pkg:/source/roku_modules/datadogroku/rum/rumRawEvents.bs"
'import "pkg:/source/roku_modules/datadogroku/rum/rumHelper.bs"
'import "pkg:/source/roku_modules/datadogroku/datadogSdk.bs"
'import "pkg:/source/roku_modules/datadogroku/internalLogger.bs"
' *****************************************************************
' * RumAgent: a background component listening for internal events
' *     to write relevant RUM Event to Datadog.
' *****************************************************************

' ----------------------------------------------------------------
' Initialize the component
' ----------------------------------------------------------------
sub init()
    datadogroku_ddLogThread("RumAgent.init()")
    m.port = createObject("roMessagePort")
    m.top.observeFieldScoped("startView", m.port)
    m.top.observeFieldScoped("stopView", m.port)
    m.top.observeFieldScoped("addAction", m.port)
    m.top.observeFieldScoped("addError", m.port)
    m.top.observeFieldScoped("addResource", m.port)
    m.top.observeFieldScoped("addConfigTelemetry", m.port)
    m.top.observeFieldScoped("addErrorTelemetry", m.port)
    m.top.observeFieldScoped("addDebugTelemetry", m.port)
    m.top.observeFieldScoped("startOperation", m.port)
    m.top.observeFieldScoped("succeedOperation", m.port)
    m.top.observeFieldScoped("failOperation", m.port)
    m.top.observeFieldScoped("areFieldsSet", m.port)
    'Observe nodes injected by the test
    m.top.observeFieldScoped("uploader", m.port)
    m.top.observeFieldScoped("writer", m.port)
    m.top.observeFieldScoped("rumScope", m.port)
    m.top.observeFieldScoped("telemetryScope", m.port)
    m.top.functionName = "datadogroku_rumAgentLoop"
    m.top.control = "RUN"
end sub

' ----------------------------------------------------------------
' Main RumAgent loop
' ----------------------------------------------------------------
sub datadogroku_rumAgentLoop()
    datadogroku_ddLogThread("RumAgent.rumAgentLoop()")
    while (true)
        msg = wait(0, m.port)
        msgType = type(msg)
        if (msgType = "roSGNodeEvent")
            fieldName = msg.getField()
            if (fieldName = "startView")
                __datadogroku_onStartView(msg.getData())
            else if (fieldName = "stopView")
                __datadogroku_onStopView(msg.getData())
            else if (fieldName = "addAction")
                __datadogroku_onAddAction(msg.getData())
            else if (fieldName = "addError")
                __datadogroku_onAddError(msg.getData())
            else if (fieldName = "addResource")
                __datadogroku_onAddResource(msg.getData())
            else if (fieldName = "addConfigTelemetry")
                __datadogroku_onAddConfigTelemetry(msg.getData())
            else if (fieldName = "addErrorTelemetry")
                __datadogroku_onAddErrorTelemetry(msg.getData())
            else if (fieldName = "addDebugTelemetry")
                __datadogroku_onAddDebugTelemetry(msg.getData())
            else if (fieldName = "startOperation")
                __datadogroku_onStartOperation(msg.getData())
            else if (fieldName = "succeedOperation")
                __datadogroku_onSucceedOperation(msg.getData())
            else if (fieldName = "failOperation")
                __datadogroku_onFailOperation(msg.getData())
            else if (fieldName = "uploader")
                m.uploader = msg.getData()
            else if (fieldName = "writer")
                m.writer = msg.getData()
            else if (fieldName = "rumScope")
                m.rumScope = msg.getData()
            else if (fieldName = "telemetryScope")
                m.telemetryScope = msg.getData()
            else if (fieldName = "areFieldsSet")
                if (msg.getData())
                    datadogroku_updateFields()
                end if
            end if
        else
            datadogroku_ddLogWarning("Unexpected message " + msgType + ": " + FormatJson(msg))
        end if
    end while
end sub

' ----------------------------------------------------------------
' Starts a view
' @param name (string) the view name (human-readable)
' @param url (string) the view url (developer identifier)
' @param context (object) an assocarray of custom attributes to add to the view
' ----------------------------------------------------------------
sub startView(name as string, url as string, context = {} as object)
    m.top.startView = datadogroku_startViewEvent(name, url, context)
end sub

' ----------------------------------------------------------------
' Private: Handles startView field change event
' @param event (object) the startView event data
' ----------------------------------------------------------------
sub __datadogroku_onStartView(event as object)
    datadogroku_ensureSetup()
    if (m.rumScope <> invalid)
        m.rumScope.callfunc("handleEvent", event, m.writer)
        m.rumScope.callfunc("handleEvent", datadogroku_keepAliveEvent(), m.writer)
    end if
end sub

' ----------------------------------------------------------------
' Stops a view
' @param name (string) the view name (human-readable)
' @param url (string) the view url (developer identifier)
' @param context (object) an assocarray of custom attributes to add to the view
' ----------------------------------------------------------------
sub stopView(name as string, url as string, context = {} as object)
    m.top.stopView = datadogroku_stopViewEvent(name, url, context)
end sub

' ----------------------------------------------------------------
' Private: Handles stopView field change event
' @param event (object) the stopView event data
' ----------------------------------------------------------------
sub __datadogroku_onStopView(event as object)
    datadogroku_ensureSetup()
    if (m.rumScope <> invalid)
        m.rumScope.callfunc("handleEvent", event, m.writer)
    end if
end sub

' ----------------------------------------------------------------
' Adds an action
' @param action (object) the action to track
' @param context (object) an assocarray of custom attributes to add to the view
' ----------------------------------------------------------------
sub addAction(action as object, context = {} as object)
    m.top.addAction = datadogroku_addActionEvent(action, context)
end sub

' ----------------------------------------------------------------
' Private: Handles addAction field change event
' @param event (object) the addAction event data
' ----------------------------------------------------------------
sub __datadogroku_onAddAction(event as object)
    datadogroku_ensureSetup()
    if (m.rumScope <> invalid)
        m.rumScope.callfunc("handleEvent", event, m.writer)
    end if
end sub

' ----------------------------------------------------------------
' Adds an error
' @param exception (object) the caught exception object
' @param context (object) an assocarray of custom attributes to add to the view
' ----------------------------------------------------------------
sub addError(exception as object, context = {} as object)
    m.top.addError = datadogroku_addErrorEvent(exception, context)
end sub

' ----------------------------------------------------------------
' Private: Handles addError field change event
' @param event (object) the addError event data
' ----------------------------------------------------------------
sub __datadogroku_onAddError(event as object)
    datadogroku_ensureSetup()
    if (m.rumScope <> invalid)
        m.rumScope.callfunc("handleEvent", event, m.writer)
    end if
end sub

' ----------------------------------------------------------------
' Adds a resource
' @param resource (object) the tracked resource object (as retrieved from the roSystemLog)
' @param context (object) an assocarray of custom attributes to add to the view
' ----------------------------------------------------------------
sub addResource(resource as object, context = {} as object)
    m.top.addResource = datadogroku_addResourceEvent(resource, context)
end sub

' ----------------------------------------------------------------
' Private: Handles addResource field change event
' @param event (object) the addResource event data
' ----------------------------------------------------------------
sub __datadogroku_onAddResource(event as object)
    datadogroku_ensureSetup()
    if (m.rumScope <> invalid)
        m.rumScope.callfunc("handleEvent", event, m.writer)
    end if
end sub

' ----------------------------------------------------------------
' Private: Handles sendCrash field change event
' @param lastExitOrTerminationReason (string) the last exit or termination reason
' ----------------------------------------------------------------
sub sendCrash(lastExitOrTerminationReason as string)
    datadogroku_ensureSetup()
    crashReporter = CreateObject("roSGNode", "datadogroku_RumCrashReporterTask")
    crashReporter.writer = m.writer
    if (m.osVersionMajor.toInt() >= 13)
        appManager = createObject("roAppManager")
        lastExitInfo = appManager.GetLastExitInfo()
        exitCode = lastExitInfo.exit_code
        crashReporter.lastExitOrTerminationReason = lastExitInfo.exit_code
        crashReporter.lastExitConsoleLog = lastExitInfo.console_log
    else
        crashReporter.lastExitOrTerminationReason = lastExitOrTerminationReason
        crashReporter.lastExitConsoleLog = ""
    end if
    crashReporter.instanceId = m.instanceId
    crashReporter.control = "RUN"
end sub

' ----------------------------------------------------------------
' Adds a telemetry config event
' @param configuration (object) the configuration information
' ----------------------------------------------------------------
sub addConfigTelemetry(configuration as object)
    m.top.addConfigTelemetry = datadogroku_addTelemetryConfigEvent(configuration)
end sub

' ----------------------------------------------------------------
' Private: Handles addConfigTelemetry field change event
' @param event (object) the addConfigTelemetry event data
' ----------------------------------------------------------------
sub __datadogroku_onAddConfigTelemetry(event as object)
    datadogroku_ensureSetup()
    m.telemetryScope.callfunc("handleEvent", event, m.writer)
end sub

' ----------------------------------------------------------------
' Adds a telemetry error event
' @param exception (object) the caught exception object
' ----------------------------------------------------------------
sub addErrorTelemetry(exception as object)
    m.top.addErrorTelemetry = datadogroku_addTelemetryErrorEvent(exception)
end sub

' ----------------------------------------------------------------
' Private: Handles addErrorTelemetry field change event
' @param event (object) the addErrorTelemetry event data
' ----------------------------------------------------------------
sub __datadogroku_onAddErrorTelemetry(event as object)
    datadogroku_ensureSetup()
    m.telemetryScope.callfunc("handleEvent", event, m.writer)
end sub

' ----------------------------------------------------------------
' Adds a telemetry debug event
' @param message (string) the message to send
' ----------------------------------------------------------------
sub addDebugTelemetry(message as string)
    m.top.addDebugTelemetry = datadogroku_addTelemetryDebugEvent(message)
end sub

' ----------------------------------------------------------------
' Private: Handles addDebugTelemetry field change event
' @param event (object) the addDebugTelemetry event data
' ----------------------------------------------------------------
sub __datadogroku_onAddDebugTelemetry(event as object)
    datadogroku_ensureSetup()
    m.telemetryScope.callfunc("handleEvent", event, m.writer)
end sub

' ----------------------------------------------------------------
' Starts a feature operation
' @param name (string) the operation name (e.g.: "login", "checkout")
' @param operationKey (dynamic) the operation key for distinguishing parallel
'     operations, or invalid for unkeyed operations
' @param context (object) an assocarray of custom attributes to add to the event
' ----------------------------------------------------------------
sub startOperation(name as string, operationKey = invalid as dynamic, context = {} as object)
    if (not __datadogroku_isValidOperationName(name))
        datadogroku_ddLogError("RumAgent: startOperation called with blank name, ignoring")
        return
    end if
    if (not __datadogroku_isValidOperationKey(operationKey))
        datadogroku_ddLogError("RumAgent: startOperation called with blank operationKey, ignoring")
        return
    end if
    m.top.startOperation = datadogroku_startFeatureOperationEvent(name, operationKey, context)
end sub

' ----------------------------------------------------------------
' Private: Handles startOperation field change event
' @param event (object) the startOperation event data
' ----------------------------------------------------------------
sub __datadogroku_onStartOperation(event as object)
    datadogroku_ensureSetup()
    if (m.rumScope <> invalid)
        m.rumScope.callfunc("handleEvent", event, m.writer)
    end if
end sub

' ----------------------------------------------------------------
' Succeeds a feature operation
' @param name (string) the operation name (e.g.: "login", "checkout")
' @param operationKey (dynamic) the operation key for distinguishing parallel
'     operations, or invalid for unkeyed operations
' @param context (object) an assocarray of custom attributes to add to the event
' ----------------------------------------------------------------
sub succeedOperation(name as string, operationKey = invalid as dynamic, context = {} as object)
    if (not __datadogroku_isValidOperationName(name))
        datadogroku_ddLogError("RumAgent: succeedOperation called with blank name, ignoring")
        return
    end if
    if (not __datadogroku_isValidOperationKey(operationKey))
        datadogroku_ddLogError("RumAgent: succeedOperation called with blank operationKey, ignoring")
        return
    end if
    m.top.succeedOperation = datadogroku_succeedFeatureOperationEvent(name, operationKey, context)
end sub

' ----------------------------------------------------------------
' Private: Handles succeedOperation field change event
' @param event (object) the succeedOperation event data
' ----------------------------------------------------------------
sub __datadogroku_onSucceedOperation(event as object)
    datadogroku_ensureSetup()
    if (m.rumScope <> invalid)
        m.rumScope.callfunc("handleEvent", event, m.writer)
    end if
end sub

' ----------------------------------------------------------------
' Fails a feature operation
' @param name (string) the operation name (e.g.: "login", "checkout")
' @param failureReason (string) the failure reason (use "error", "abandoned", or "other")
' @param operationKey (dynamic) the operation key for distinguishing parallel
'     operations, or invalid for unkeyed operations
' @param context (object) an assocarray of custom attributes to add to the event
' ----------------------------------------------------------------
sub failOperation(name as string, failureReason as string, operationKey = invalid as dynamic, context = {} as object)
    if (not __datadogroku_isValidOperationName(name))
        datadogroku_ddLogError("RumAgent: failOperation called with blank name, ignoring")
        return
    end if
    if (not __datadogroku_isValidOperationKey(operationKey))
        datadogroku_ddLogError("RumAgent: failOperation called with blank operationKey, ignoring")
        return
    end if
    if (not __datadogroku_isValidFailureReason(failureReason))
        datadogroku_ddLogError("RumAgent: failOperation called with invalid failureReason '" + failureReason + "', ignoring")
        return
    end if
    m.top.failOperation = datadogroku_failFeatureOperationEvent(name, operationKey, failureReason, context)
end sub

' ----------------------------------------------------------------
' Private: Handles failOperation field change event
' @param event (object) the failOperation event data
' ----------------------------------------------------------------
sub __datadogroku_onFailOperation(event as object)
    datadogroku_ensureSetup()
    if (m.rumScope <> invalid)
        m.rumScope.callfunc("handleEvent", event, m.writer)
    end if
end sub

' ----------------------------------------------------------------
' Returns true if the operation name is valid (non-blank after trimming)
' @param name (string) the operation name to validate
' @return (boolean) whether the name is valid
' ----------------------------------------------------------------
function __datadogroku_isValidOperationName(name as string) as boolean
    return name.Trim().Len() > 0
end function

' ----------------------------------------------------------------
' Returns true if the operationKey is valid:
'   - invalid is VALID (means unkeyed operation)
'   - non-empty string after trimming is VALID
'   - empty or whitespace-only string is INVALID
'   - non-string, non-invalid values are INVALID
' @param operationKey (dynamic) the operation key to validate
' @return (boolean) whether the key is valid
' ----------------------------------------------------------------
function __datadogroku_isValidOperationKey(operationKey as dynamic) as boolean
    if (operationKey = invalid)
        return true
    end if
    if (type(operationKey) = "roString" or type(operationKey) = "String")
        return operationKey.Trim().Len() > 0
    end if
    ' Non-string, non-invalid values are invalid
    return false
end function

' ----------------------------------------------------------------
' Returns true if the failureReason is a known FailureReason value
' @param failureReason (string) the failure reason to validate
' @return (boolean) whether the failure reason is valid
' ----------------------------------------------------------------
function __datadogroku_isValidFailureReason(reason as string) as boolean
    return (reason = "error" or reason = "abandoned" or reason = "other")
end function

' ----------------------------------------------------------------
' Ensure all dependencies are present (from DI or generated)
' ----------------------------------------------------------------
sub datadogroku_ensureSetup()
    datadogroku_ensureRumScope()
    datadogroku_ensureTelemetryScope()
    datadogroku_ensureUploader()
    datadogroku_ensureWriter()
end sub

' ----------------------------------------------------------------
' Sets the root RUM scope node from the top node's field,
' or instantiate one.
' ----------------------------------------------------------------
sub datadogroku_ensureRumScope()
    if (m.rumScope = invalid and m.areFieldsSet = true)
        m.instanceId = CreateObject("roDeviceInfo").GetRandomUUID()
        datadogroku_ddLogWarning("RumAgent.instanceId:" + m.instanceId)
        m.global.addFields({
            datadogRumContext: {
                applicationId: m.applicationId
                instanceId: m.instanceId
            }
        })
        datadogroku_ddLogVerbose("Creating RumApplicationScope")
        m.rumScope = CreateObject("roSGNode", "datadogroku_RumApplicationScope")
        m.rumScope.setFields({
            applicationId: m.applicationId
            service: m.service
            version: m.version
            deviceName: m.deviceName
            deviceModel: m.deviceModel
            osVersion: m.osVersion
            osVersionMajor: m.osVersionMajor
            sessionSampleRate: m.sessionSampleRate
        })
        m.top.rumScope = m.rumScope
    end if
end sub

' ----------------------------------------------------------------
' Sets the telemetry scope node from the top node's field,
' or instantiate one.
' ----------------------------------------------------------------
sub datadogroku_ensureTelemetryScope()
    if (m.telemetryScope = invalid)
        datadogroku_ddLogVerbose("Creating RumTelemetryScope")
        m.telemetryScope = CreateObject("roSGNode", "datadogroku_RumTelemetryScope")
        m.top.telemetryScope = m.telemetryScope
    end if
end sub

' ----------------------------------------------------------------
' Sets the uploader node from the top node's field,
' or instantiate one.
' ----------------------------------------------------------------
sub datadogroku_ensureUploader()
    if (m.uploader = invalid)
        datadogroku_ddLogVerbose("Creating MultiTrackUploaderTask")
        m.uploader = CreateObject("roSGNode", "datadogroku_MultiTrackUploaderTask")
        m.top.uploader = m.uploader
    end if
    trackId = "rum_" + m.top.threadInfo().node.address
    tracks = (function(m)
            __bsConsequent = m.uploader.tracks
            if __bsConsequent <> invalid then
                return __bsConsequent
            else
                return {}
            end if
        end function)(m)
    tracks[trackId] = {
        url: datadogroku_getIntakeUrl(m.top.site, "rum")
        trackType: "rum"
        payloadPrefix: ""
        payloadPostfix: ""
        contentType: "text/plain;charset=UTF-8"
        queryParams: {
            ddsource: datadogroku_agentSource()
            ddtags: "sdk_version:" + datadogroku_sdkVersion() + ",env:" + m.env
        }
    }
    m.uploader.setFields({
        tracks: tracks
        clientToken: m.clientToken
    })
end sub

' ----------------------------------------------------------------
' Sets the writer node from the top node's field,
' or instantiate one.
' ----------------------------------------------------------------
sub datadogroku_ensureWriter()
    if (m.writer = invalid)
        datadogroku_ddLogVerbose("Creating WriterTask")
        m.writer = CreateObject("roSGNode", "datadogroku_WriterTask")
        m.top.writer = m.writer
    end if
    m.writer.setFields({
        trackType: "rum"
        payloadSeparator: chr(10)
    })
end sub

sub datadogroku_updateFields()
    fields = m.top.getFields()
    m.applicationId = fields.applicationId
    m.service = fields.service
    m.version = fields.version
    m.deviceName = fields.deviceName
    m.deviceModel = fields.deviceModel
    m.osVersion = fields.osVersion
    m.osVersionMajor = fields.osVersionMajor
    m.sessionSampleRate = fields.sessionSampleRate
    m.clientToken = fields.clientToken
    m.env = fields.env
    m.site = fields.site
    m.areFieldsSet = fields.areFieldsSet
    ' lastExitOrTerminationReason should be set only once at startup and it triggers sendCrash.
    if (m.lastExitOrTerminationReason = invalid or m.lastExitOrTerminationReason = "")
        m.lastExitOrTerminationReason = fields.lastExitOrTerminationReason
        if (m.lastExitOrTerminationReason <> invalid and m.lastExitOrTerminationReason <> "")
            sendCrash(m.lastExitOrTerminationReason)
        end if
    end if
    ' configuration should be set only once at startup and it triggers addConfigTelemetry.
    if (m.configuration = invalid or m.configuration.Count() = 0)
        m.configuration = fields.configuration
        if (m.configuration <> invalid and m.configuration.Count() > 0)
            addConfigTelemetry(m.configuration)
        end if
    end if
end sub